import Foundation

/*
 task 2
 
 Два enum для хранения всех мастей и значений. Класс для карты с конструктором с двумя параметрами (масть и значение) для инициализации двух полей. Можно использовать пул объектов для создания всех карт и их использования.
 */
enum Value{
    
    case Six, Seven, Eight, Nine
    
}
enum Suit{
    
    case Hearts, Diamonds, Clubs, Spades
}

class Card{
    var value: Value
    var suit: Suit
    init(_ value: Value, suit: Suit) {
        self.value = value
        self.suit = suit
    }
    
}


/*
task 3
 строки, символы, целые числа, числа с плавающей точкой
 
 */

//task 4

class Circle{
    var radius: Double
    var x: CGFloat
    var y: CGFloat
    init(radius: Double, x: CGFloat, y: CGFloat) {
        self.radius = radius
        self.x = x
        self.y = y
    }
}
    
class Rectangle{
    var width: Double
    var height: Double
    var x: CGFloat
    var y: CGFloat
    init(width: Double, height: Double, x: CGFloat, y: CGFloat) {
        self.width = width
        self.height = height
        self.x = x
        self.y = y
    }
}

struct Circle2{
    var radius: Double
    var x: CGFloat
    var y: CGFloat
}
    
struct Rectangle2{
    var width: Double
    var height: Double
    var x: CGFloat
    var y: CGFloat
}

//task 5
//1- потму что name - let, 3 - user3 и name должны быть var, 4 - user4 должен быть var, 5 - name должен быть var, 7 - name должно быть var

//task 6

class Car{

    var name: String
    var type: String
    var year: Int
    var engine: Double
    
    init(_ year: Int, _ engine: Double, _ name: String = "Audi", _ type: String = "sedan" ) {
        self.year = year
        self.engine = engine
        self.name = name
        self.type = type
    }
}


//task 7

class Calc{
    
    var a: Double = 0
    var b: Double = 0
   
    func plus() -> Double {
        return a + b
    }
    func minus() -> Double {
        return a - b
    }
    func multiply() -> Double {
        return a * b
    }
    func divide() -> Double {
        return a / b
    }
}
var calc = Calc()
calc.a = 3
calc.b = 2
print(calc.plus())

//task 8
// static  следует использовать когда мы хотить получить доступ к полю либо функции без создания объекта класса

//task 9
// только классы

//task 10

enum Direction{
    case east, north, west, south
    
}
struct Coordinate{
    var x: Int = 0
    var y: Int = 0
    
}
var direction = Direction.east
var coordinate = Coordinate()
func go(_ dir: Direction, _ coord: Coordinate) -> Coordinate {
    
   
    switch dir {
    case .east:
        coordinate.x = coord.x + 1
    case .north:
        coordinate.y = coord.y + 1
    case .west:
        coordinate.x = coord.x - 1
    case .south:
        coordinate.y = coord.y - 1
              
    }
    return coordinate
}


print(go(.west, coordinate))
print(go(.south, coordinate))
print(go(.south, coordinate))


 
/*
 В enum могут быть вычисляемые свойства, функции и инициализаторы.

 Данные и функции удобно структурировать в класс когда есть неободимость создавать несколько однотипных объектов.
 
 
 Класс лучше использовать когда нужно использовать наследование и деинициализаторы.
 Структура при небольшом наборе полей.
 */
