import Foundation
// task 3

class Box{
    
    var inventoryArray: [Inventory] = []
    func add(_ inventory: Inventory) -> String {
        inventoryArray.append(inventory)
        return "\(inventory.name) in the box"
    }
    func remove(_ inventory: Inventory) -> String {
        var result:String = ""
        for (index, el) in inventoryArray.enumerated(){
            if el.name == inventory.name{
                inventoryArray.remove(at: index)
                result = "\(inventory.name) removed"
            }
            else{
                result = "Not in the box"
            }
        }
        return result
    }
    
}



class Inventory{
    var name: String
    init(_ name: String) {
        self.name = name
    }
//    func get(item: Inventory) -> String{
//
//        return "\(item.name) in box "
//    }
//    func drop(item: Inventory) -> String {
//        return "Drop \(item.name)"
//    }
    
}
class Plant: Inventory {
    
    func doSomething() -> String {
        return "\(self.name) do something"
        
    }
}

class Weapon: Inventory{
    
    func shot() -> String {
        return "\(self.name) shot"
        
    }
}
class QuestItem: Inventory {
    
    func doSomething2() -> String {
        return "\(self.name) do something2"
    }
}
var box = Box()
var plant = Plant("rose")
var weapon = Weapon("ak-47")
box.add(plant)
box.add(weapon)
box.remove(weapon)
box.remove(weapon)

weapon.shot()






protocol Drawable{
    func draw(map: Map) -> String
}

class Tree: Drawable{
    
    func draw(map: Map) -> String {
        return "Tree is draw"
    }
}
class Wall: Drawable {
    func draw(map: Map) -> String {
        return "Wall is draw"
    }
}
class Player: Drawable {
    func draw(map: Map) -> String {
        return "Player is draw"
    }
}
class Monster: Drawable {
    func draw(map: Map) -> String {
        return "Monster is draw"
    }
}
class Map{
       func draw(_ objects: Drawable...) -> String {
        var result = ""
        for obj in objects{
            result += obj.draw(map: self) + " "
        }
       return result
        
    }
}
let tree = Tree()
let wall = Wall()
let player = Player()
let monster = Monster()
let map = Map()
map.draw(tree, wall, player, monster)

 
struct Equipment{
    
    var name: String
    var price: Double
    var color: String
    var engine: Double
    
}
protocol Car{
    var Name: String {get}
    var image: String {get}
    var equipment: [Equipment] {get}
    
        
}

class A5: Car{
    var Name: String = "Audi A5"
    var image: String = "imgA5"
    var equipment: [Equipment] = [Equipment(name:"basic", price: 100, color: "black", engine: 1.9),Equipment(name: "comfort", price: 200, color: "red", engine: 2.0),Equipment(name: "premium", price: 300, color: "black", engine: 2.5)]
}

class A7: Car{
    
    var Name: String = "Audi A7"
    var image: String = "imgA7"
    var equipment: [Equipment] = [Equipment(name:"basic", price: 200, color: "black", engine: 1.9),Equipment(name: "comfort", price: 300, color: "green", engine: 2.0),Equipment(name: "premium", price: 400, color: "black", engine: 2.5)]
}

class A8: Car{
    
    var Name: String = "Audi A7"
    var image: String = "imgA7"
    var equipment: [Equipment] = [Equipment(name:"basic", price: 400, color: "black", engine: 1.9),Equipment(name: "comfort", price: 500, color: "yellow", engine: 2.0),Equipment(name: "premium", price: 600, color: "black", engine: 2.5)]
}

var a5 = A5()
var a8 = A8()
var a7 = A7()

//task 4
// Расширения используются при необходимости расширить функционал существующего класса, протокола или структуры (например можем расширить классы к которым у нас нет доступа такие как Int, String и т.д)
// Наследование используется когда мы хотим создать новый класс на основе существующего.


//task 5
//1: A
//2: ошибка, B не связан С
//3: ошибка, в классе C нет метода d
//4 A


