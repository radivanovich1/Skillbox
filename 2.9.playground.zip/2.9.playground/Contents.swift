
//task 3

let arr = [Int]()
let arr2: Array<Int>
let arr3: [Int]
let arr4: [Int] = []
// c инициализацией
let arr5: [Int] = [1,2]
let arr6 = Array(repeating: 1, count: 5)
let arr7 = Array(1...6)
let arr8 = Array(1..<6)



//task 4

var array: [Int] = [1,2,3]

array.append(4)

array.remove(at: 0)

var max: Int
var min: Int
max = array[0]
min = array[0]
for i in array{
    
    if i>max{
        max = i
    }
    if i<min{
        min = i
    }
    
}

print(max - min)

// task 5

array.append(5)
array += [6]
let newArr: [Int] = [1]
array = array + newArr
array.insert(9, at: 6)

//task 6
// Ответ 11

//task 7

let people: [String] = ["Nick", "Mike","Dima", "Alex"]
var greeting = ""
var i = 0
for (index,name) in people.enumerated(){
       if(index % 2 == 0)
    {
        greeting += "Go left, \(name) "
    }
    else{
        greeting += "Go right, \(name) "
    }
}

// task 8

// В массиве элементы находятся в определённом порядке( индексированны) и элементы массива могут повторяться. В сете всё наоборот. Сет можно использовать когда нужно исключить повторяющиеся значения.

// task 9
/*
myEmoji.intersection(wifeEmoji) 🎊, 😂
myEmoji.symmetricDifference(wifeEmoji) 🦋, 🚀, 🕺, 🎸
myEmoji.union(wifeEmoji) 🕺, 🚀, 🎸, 🎊, 😂, 🦋
myEmoji.subtracting(wifeEmoji) 🚀, 🕺
 */

// task 10
/*
 телефонная книга - Dictionary
 список покупок - Set
 суточная температура - Array
 */

// task 11

let number = 5
let power = 3
var res = number

for _ in 1..<power{
    res *= number
}

print(res)

// task 12

let mood = 7
if (mood>=0 && mood<=3){
    print("sad")
}
else if (mood>=4 && mood<=7){
    print("normal")
}
else if (mood>=8 && mood<=10){
    print("happy")
}
else{
    print("error")
}

switch mood {
case 0...3:
    print("sad")
case 4...7:
    print("normal")
case 8...10:
    print("happy")
default:
    print("error")
}

/* доп задания
 🏆, 💃, 💃🎰
 Good emoji
 24
 if используется для определения блока кода который выполнится при соблюдении условия
 switch нужен для определения нескольких альтернативных блоков
 */


