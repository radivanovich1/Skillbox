
//task 2
// может
//при вызове функци test вызовется concat
func test(){
    print("Hi!")
    concat(["H","i!"])
}

//task 3
let arr:[String] = ["a","b","c"]
func concat(_ param:[String]) -> String {
    
var result = ""
for el in param{
    result += el+","
    
}
    result.removeLast()
    return result
    
    
}

print(concat(arr))

//task 4

func swap(_ a: inout Int , _ b:inout Int){
    let c = b
    b = a * 2
    a = c * 2
    
}

var a = 1;
var b = 2;
swap(&a , &b)
print(a , b)



//task 5
let arr1 = [1,5,3]
let arr2 = [2,2,3]

func summ(_ first:[Int],_ second:[Int]) -> Bool {
    var summ1 = 0
    var summ2 = 0
    for num in first {
        summ1 += num
    }
    for num in second{
        summ2 += num
    }
    if summ1 > summ2 {
        return true
    }
    else {
        return false
    }
}

print(summ(arr1,arr2))

// task 6
func sort(_ arr:[Int]) -> [Int] {
   
    return arr.sorted(by: >)
}

print(sort(arr1))

// task 7

func avg(_ arr:[Int]) -> Double {
 var res = 0
   for el in arr{
       res += el
       
   }
    return Double(res / arr.count)
}

print(avg(arr1))

//task 8
var i: Int?
func search(_ arr: [String], _ str: String) -> Int? {
    for(index, el) in arr.enumerated(){
        
     if el == str
     {
        i = index
     }
      
    }
 return i
}
print(search(arr, "b"))

//task 9
//Hello, young man/woman 0

//task 10
// 4


/*
 доп задания
 
 можно
 
 восклицательный знак для опционалов можно использовать только когда мы уверены что значение не nil
 */

