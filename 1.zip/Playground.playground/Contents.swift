import Foundation
/*
2. let - константа, var - изменяемое значение.
3. Возможен.
4. a-Int, b-Double, c-String, d-UInt8, e-Int
5. Ошибка (переполнение)
6. Кортежи удобно использовать когда нам нужно вернуть несколько значений разных типов. Например день и температура:
*/
let weather = ("monday", -5)
//  id, email и имя
let user = (1, "swift@mail.ru", "Alex")
// ну и с булькой что-нибудь...
let result = (true, "message") 
//тэги
let name = (first: "Nilita", last: "Ivanov")

/*
7. "Hello \(name), your age is \(age)"
8.  a=2
    b=5
    c=false
    d=true
    e=false
    f=true
*/

